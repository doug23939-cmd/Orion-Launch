Orion Launcher 2.0 - Android project (Kotlin).

BUILD (no PC): upload this whole folder to a new GitHub repo, open Actions -> "Build Orion Launcher" -> Run workflow.
When it finishes, download the artifact "OrionLauncher-apk" (a zip with app-debug.apk) and install it.
Or open in Android Studio and press Run.

AFTER INSTALL: Settings (long-press empty area -> Settings) ->
  "Make Orion the default launcher"
  "Notification access" (badges)
  "Enable accessibility service" (lock screen / recents / power menu / screenshot gestures)

WHAT'S NEW IN 2.0
- Several home screens, swipe sideways. Free placement: long-press an icon and drop it on any cell, on any page.
  Drag to the screen edge to switch page; dragging past the last page makes a new one.
  Long-press and release in the same place opens the app menu (shortcuts, info, uninstall, rename, hide...).
- Drop an icon on another icon to make a folder. Folders live on the home screen too.
- Widgets are placed on pages (long-press widget: move / resize / remove). Built-in clock and search bar.
- App drawer: swipe up. Grid or list, sort A-Z / Z-A / newest / most used.
- Search (drawer): apps (fuzzy + initials), contacts, web suggestions + choice of search engine, calculator,
  quick actions (Wi-Fi, flashlight, lock...), recent apps and recent searches.
- Gestures: swipe up/down, two-finger swipe up/down, pinch in/out, double tap, long press. Each can run:
  notifications, quick settings, lock, settings, search, recents, power menu, screenshot, app drawer,
  home menu, flashlight, first page, add widget, or open any app.
- Page animations: slide, zoom, cube, depth, flip, fade. Grid styles: classic, tiles, compact, minimal.
  Icon appear animation, app launch animation, drawer open animation, page indicator styles.
- Icon packs (ADW / Nova / Apex / GO themes), icon corner radius, icon background tiles.
- Backup: save to a file / restore from a file, or via clipboard. Includes the whole home layout.
- Extras: rename apps, hide apps, lock layout, hide status bar, grid size, wallpaper picker, notification badges.

PRIVACY
- Contacts are read only when you search (asks for permission).
- Web suggestions send the text you type to DuckDuckGo. Turn it off in Settings -> SEARCH.
