package com.orion.launcher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import org.json.JSONArray
import org.json.JSONObject

class App(val pkg: String, val cls: String, var label: String, var icon: Drawable, val orig: String = label)

/** One thing placed on a home page: app, folder, widget, clock or search bar. */
class Item(var type: String, var data: String, var page: Int, var col: Int, var row: Int, var sx: Int = 1, var sy: Int = 1)

/** A search result row (contact, web suggestion, quick action, calculator ...). */
class Hit(val emoji: String, val title: String, val sub: String, val alt: (() -> Unit)? = null, val run: () -> Unit)

class Sc(val label: String, val run: () -> Unit)

val ACTS = listOf(
    "None", "Notifications", "Quick settings", "Lock screen", "Orion settings", "Search (keyboard)", "Recent apps",
    "Power menu", "Screenshot", "App drawer", "Home menu", "Flashlight", "First home page", "Add widget", "Open an app..."
)

val ENGINES = listOf(
    Pair("Google", "https://www.google.com/search?q=%s"),
    Pair("DuckDuckGo", "https://duckduckgo.com/?q=%s"),
    Pair("Bing", "https://www.bing.com/search?q=%s"),
    Pair("Yandex", "https://yandex.com/search/?text=%s"),
    Pair("Brave", "https://search.brave.com/search?q=%s"),
    Pair("Wikipedia", "https://wikipedia.org/w/index.php?search=%s")
)

val XFORMS = listOf("None", "Slide", "Zoom", "Cube", "Depth", "Flip", "Fade")

class Calc(val s: String) {
    var i = 0
    fun ws() { while (i < s.length && s[i] == ' ') i++ }
    fun parse(): Double { val v = expr(); ws(); if (i != s.length) throw Exception(); return v }
    fun expr(): Double { var v = term(); while (true) { ws(); if (i < s.length && (s[i] == '+' || s[i] == '-')) { val o = s[i++]; val t = term(); v = if (o == '+') v + t else v - t } else return v } }
    fun term(): Double { var v = fac(); while (true) { ws(); if (i < s.length && (s[i] == '*' || s[i] == '/' || s[i] == 'x' || s[i] == '×')) { val o = s[i++]; val t = fac(); v = if (o == '/') v / t else v * t } else return v } }
    fun fac(): Double {
        ws()
        if (i < s.length && s[i] == '-') { i++; return -fac() }
        if (i < s.length && s[i] == '(') { i++; val v = expr(); ws(); if (i >= s.length || s[i] != ')') throw Exception(); i++; return v }
        val st = i; while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
        if (st == i) throw Exception(); return s.substring(st, i).toDouble()
    }
}

/** Home layout: pages and the items placed on them, stored as JSON in SharedPreferences ("home"). */
class Layout(private val sp: SharedPreferences) {
    var pages = 1
    val items = ArrayList<Item>()

    fun has(): Boolean = sp.contains("home")

    fun load() {
        items.clear(); pages = 1
        val s = sp.getString("home", null) ?: return
        try {
            val j = JSONObject(s)
            pages = maxOf(1, j.optInt("pages", 1))
            val a = j.getJSONArray("items")
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                items.add(Item(o.getString("t"), o.getString("d"), o.getInt("p"), o.getInt("c"), o.getInt("r"), o.optInt("sx", 1), o.optInt("sy", 1)))
            }
        } catch (e: Exception) {}
    }

    fun save() {
        val a = JSONArray()
        items.forEach { m -> a.put(JSONObject().put("t", m.type).put("d", m.data).put("p", m.page).put("c", m.col).put("r", m.row).put("sx", m.sx).put("sy", m.sy)) }
        sp.edit().putString("home", JSONObject().put("pages", pages).put("items", a).toString()).apply()
    }

    fun onPage(p: Int): List<Item> = items.filter { it.page == p }

    fun at(p: Int, c: Int, r: Int, ignore: Item?): Item? =
        items.firstOrNull { it !== ignore && it.page == p && c >= it.col && c < it.col + it.sx && r >= it.row && r < it.row + it.sy }

    fun fits(p: Int, c: Int, r: Int, sx: Int, sy: Int, cols: Int, rows: Int, ignore: Item?): Boolean {
        if (c < 0 || r < 0 || c + sx > cols || r + sy > rows) return false
        for (x in c until c + sx) for (y in r until r + sy) if (at(p, x, y, ignore) != null) return false
        return true
    }

    fun findFree(p: Int, sx: Int, sy: Int, cols: Int, rows: Int, ignore: Item?): IntArray? {
        for (r in 0..(rows - sy)) for (c in 0..(cols - sx)) if (fits(p, c, r, sx, sy, cols, rows, ignore)) return intArrayOf(c, r)
        return null
    }

    /** Put the item on the first page (starting at its own page) that has room; adds a page if all are full. */
    fun place(m: Item, cols: Int, rows: Int) {
        m.sx = minOf(m.sx, cols); m.sy = minOf(m.sy, rows)
        val start = m.page.coerceIn(0, pages - 1)
        for (k in 0 until pages) {
            val p = (start + k) % pages
            val f = findFree(p, m.sx, m.sy, cols, rows, m)
            if (f != null) { m.page = p; m.col = f[0]; m.row = f[1]; if (!items.contains(m)) items.add(m); return }
        }
        pages++; m.page = pages - 1; m.col = 0; m.row = 0
        if (!items.contains(m)) items.add(m)
    }

    /** After the grid size changed: move anything that no longer fits. */
    fun clamp(cols: Int, rows: Int) {
        items.toList().forEach { m ->
            if (m.page >= pages) m.page = pages - 1
            if (m.col < 0 || m.row < 0 || m.col + m.sx > cols || m.row + m.sy > rows) { items.remove(m); place(m, cols, rows) }
        }
    }
}

/** One home page. Children are positioned by their Item (tag) on a cols x rows grid. */
class Grid(c: Context) : ViewGroup(c) {
    var cols = 4
    var rows = 6
    var hl: RectF? = null
    private val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x40FFFFFF }

    init { setWillNotDraw(false) }

    override fun onMeasure(ws: Int, hs: Int) {
        val w = MeasureSpec.getSize(ws); val h = MeasureSpec.getSize(hs)
        setMeasuredDimension(w, h)
        val cw = w / cols; val ch = h / rows
        for (i in 0 until childCount) {
            val v = getChildAt(i); val m = v.tag as? Item ?: continue
            v.measure(MeasureSpec.makeMeasureSpec(cw * m.sx, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ch * m.sy, MeasureSpec.EXACTLY))
        }
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val cw = (r - l) / cols; val ch = (b - t) / rows
        for (i in 0 until childCount) {
            val v = getChildAt(i); val m = v.tag as? Item ?: continue
            v.layout(m.col * cw, m.row * ch, (m.col + m.sx) * cw, (m.row + m.sy) * ch)
        }
    }

    override fun onDraw(canvas: Canvas) { val r = hl; if (r != null) canvas.drawRoundRect(r, 28f, 28f, hp) }

    fun cell(x: Float, y: Float): IntArray {
        val cw = maxOf(1, width / cols); val ch = maxOf(1, height / rows)
        return intArrayOf((x / cw).toInt().coerceIn(0, cols - 1), (y / ch).toInt().coerceIn(0, rows - 1))
    }
}

/** Horizontal pager that snaps to whole pages and reports scroll so pages can be transformed. */
class Pg(c: Context) : HorizontalScrollView(c) {
    var onPage: (Int) -> Unit = {}
    var xform: () -> Unit = {}
    private var flung = false

    private fun maxPage(): Int { val w = width; val c = getChildAt(0); return if (w > 0 && c != null) maxOf(0, c.width / w - 1) else 0 }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action == MotionEvent.ACTION_DOWN) flung = false
        val r = super.onTouchEvent(e)
        if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
            val w = width
            if (w > 0 && !flung) post { smoothScrollTo(((scrollX + w / 2) / w).coerceIn(0, maxPage()) * w, 0) }
        }
        return r
    }

    override fun fling(velocityX: Int) {
        val w = width
        if (w <= 0) { super.fling(velocityX); return }
        flung = true
        val cur = scrollX.toFloat() / w
        val t = if (velocityX > 500) Math.ceil(cur.toDouble()).toInt() else if (velocityX < -500) Math.floor(cur.toDouble()).toInt() else Math.round(cur)
        smoothScrollTo(t.coerceIn(0, maxPage()) * w, 0)
    }

    override fun onScrollChanged(l: Int, t: Int, ol: Int, ot: Int) {
        super.onScrollChanged(l, t, ol, ot)
        xform()
        onPage(if (width > 0) (scrollX + width / 2) / width else 0)
    }
}
