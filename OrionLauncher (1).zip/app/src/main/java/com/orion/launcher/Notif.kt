package com.orion.launcher

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class Notif : NotificationListenerService() {
    companion object { val counts = HashMap<String, Int>(); var cb: (() -> Unit)? = null }
    private fun sync() {
        val m = HashMap<String, Int>()
        try { activeNotifications?.forEach { if (it.notification.flags and Notification.FLAG_GROUP_SUMMARY == 0) m[it.packageName] = (m[it.packageName] ?: 0) + 1 } } catch (e: Exception) {}
        counts.clear(); counts.putAll(m); cb?.invoke()
    }
    override fun onListenerConnected() { sync() }
    override fun onNotificationPosted(s: StatusBarNotification?) { sync() }
    override fun onNotificationRemoved(s: StatusBarNotification?) { sync() }
}
